import React, { createContext, useContext, useState, useEffect } from 'react';
import type { ReactNode } from 'react';
import type { User, AuthState, LoginFormData, SignUpFormData } from '../types/auth';
import { authStorage } from '../utils/authStorage';

interface AuthContextType extends AuthState {
  login: (formData: LoginFormData) => Promise<{ success: boolean; error?: string }>;
  signUp: (formData: SignUpFormData) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock users for demonstration (in real app, this would be handled by backend)
const mockUsers: User[] = [
  {
    id: '1',
    email: 'admin@example.com',
    name: 'Admin User',
    userType: 'admin',
    createdAt: new Date().toISOString(),
  },
  {
    id: '2',
    email: 'user@example.com',
    name: 'Regular User',
    userType: 'user',
    createdAt: new Date().toISOString(),
  },
];

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
    isLoading: true,
  });

  useEffect(() => {
    const initializeAuth = () => {
      // Set up demo account passwords if not already set
      if (!localStorage.getItem('password_admin@example.com')) {
        localStorage.setItem('password_admin@example.com', 'Admin123!');
      }
      if (!localStorage.getItem('password_user@example.com')) {
        localStorage.setItem('password_user@example.com', 'User123!');
      }

      const savedUser = authStorage.getUser();
      const session = authStorage.getSession();

      if (savedUser && session) {
        setAuthState({
          user: savedUser,
          isAuthenticated: true,
          isLoading: false,
        });
      } else {
        setAuthState({
          user: null,
          isAuthenticated: false,
          isLoading: false,
        });
      }
    };

    initializeAuth();
  }, []);

  const login = async (formData: LoginFormData): Promise<{ success: boolean; error?: string }> => {
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Mock authentication - check against predefined users or localStorage
      let user = mockUsers.find(u => u.email === formData.email);
      
      // Also check localStorage for registered users
      const registeredUsers = JSON.parse(localStorage.getItem('registered_users') || '[]');
      if (!user) {
        user = registeredUsers.find((u: User) => u.email === formData.email);
      }

      // Simple password check (in real app, passwords would be hashed)
      const storedPassword = localStorage.getItem(`password_${formData.email}`) || 
                           (formData.email === 'admin@example.com' ? 'Admin123!' : 
                            formData.email === 'user@example.com' ? 'User123!' : null);

      if (!user || !storedPassword || storedPassword !== formData.password) {
        return { success: false, error: 'Invalid email or password' };
      }

      // Generate session token
      const sessionToken = btoa(`${user.id}_${Date.now()}`);

      // Save to storage
      authStorage.saveUser(user);
      authStorage.saveSession(sessionToken);

      setAuthState({
        user,
        isAuthenticated: true,
        isLoading: false,
      });

      return { success: true };
    } catch (error) {
      return { success: false, error: 'Login failed. Please try again.' };
    }
  };

  const signUp = async (formData: SignUpFormData): Promise<{ success: boolean; error?: string }> => {
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Check if user already exists
      const existingUsers = JSON.parse(localStorage.getItem('registered_users') || '[]');
      const userExists = existingUsers.some((u: User) => u.email === formData.email) ||
                        mockUsers.some(u => u.email === formData.email);

      if (userExists) {
        return { success: false, error: 'User with this email already exists' };
      }

      // Create new user
      const newUser: User = {
        id: Date.now().toString(),
        email: formData.email,
        name: formData.name,
        userType: formData.userType,
        createdAt: new Date().toISOString(),
      };

      // Save user to localStorage (mock database)
      const updatedUsers = [...existingUsers, newUser];
      localStorage.setItem('registered_users', JSON.stringify(updatedUsers));
      localStorage.setItem(`password_${formData.email}`, formData.password);

      return { success: true };
    } catch (error) {
      return { success: false, error: 'Registration failed. Please try again.' };
    }
  };

  const logout = () => {
    authStorage.clearAll();
    setAuthState({
      user: null,
      isAuthenticated: false,
      isLoading: false,
    });
  };

  const value: AuthContextType = {
    ...authState,
    login,
    signUp,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
